# Luzmo Flex showcase: Report builder

## Installation
```
npm install
```

## Run
```
npm start
```
