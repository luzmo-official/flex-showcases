import { AppEnvironment } from './environment-model';

export const environmentLocalCommonConfig: Pick<AppEnvironment, 'production'> = {
  production: false
};
