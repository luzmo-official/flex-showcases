import "./chunk-LJ4VCL4A.js";

// node_modules/userflow.js/dist/userflow.es.js
function detectBrowserTarget(agent) {
  var options = [
    // Edge. Can contain "Chrome", so must come before Chrome.
    [/Edg\//, /Edg\/(\d+)/, 80],
    // Opera. Can contain "Chrome", so must come before Chrome
    [/OPR\//, /OPR\/(\d+)/, 67],
    // Chrome. Can contain "Safari", so must come before Safari.
    [/Chrome\//, /Chrome\/(\d+)/, 80],
    // Chrome on iOS. Can contain "Safari", so must come before Safari.
    // I'm not sure exactly what the engine driving Chrome iOS is, but assuming
    // it's based on iOS Safari, which hit v14 (that's es2020 compatible) on
    // September 16, 2020, and CriOS apparently hit v100 in April 11, 2022, we
    // just go with 100.
    [/CriOS\//, /CriOS\/(\d+)/, 100],
    // Safari
    [/Safari\//, /Version\/(\d+)/, 14],
    // Firefox
    [/Firefox\//, /Firefox\/(\d+)/, 74]
  ];
  for (var i = 0; i < options.length; i++) {
    var option = options[i];
    var browserRegExp = option[0];
    var versionRegExp = option[1];
    var minVersion = option[2];
    if (!agent.match(browserRegExp)) {
      continue;
    }
    var versionMatch = agent.match(new RegExp(versionRegExp));
    if (versionMatch) {
      var version = parseInt(versionMatch[1], 10);
      if (version >= minVersion) {
        return "es2020";
      }
    }
    break;
  }
  return "legacy";
}
var w = typeof window === "undefined" ? {} : window;
var userflow = w.userflow;
var history = w.history;
function overrideHistoryMethods(method, eventName) {
  return function() {
    var event = new CustomEvent(eventName);
    var args = Array.prototype.slice.call(arguments);
    var ret = method.apply(history, args);
    w.dispatchEvent(event);
    return ret;
  };
}
if (history) {
  w.__userflowStatePatched = true;
  originalPushState = history.pushState;
  originalReplaceState = history.replaceState;
  history.pushState = overrideHistoryMethods(originalPushState, "userflow:pushstate");
  history.replaceState = overrideHistoryMethods(originalReplaceState, "userflow:replacestate");
}
var originalPushState;
var originalReplaceState;
if (!userflow) {
  urlPrefix = "https://js.userflow.com/";
  loadPromise = null;
  userflow = w.userflow = {
    _stubbed: true,
    // Helper to inject the proper Userflow.js script/module into the document
    load: function() {
      if (!loadPromise) {
        loadPromise = new Promise(function(resolve, reject) {
          var script = document.createElement("script");
          script.async = true;
          var envVars = w.USERFLOWJS_ENV_VARS || {};
          var browserTarget = envVars.USERFLOWJS_BROWSER_TARGET || detectBrowserTarget(navigator.userAgent);
          if (browserTarget === "es2020") {
            script.type = "module";
            script.src = envVars.USERFLOWJS_ES2020_URL || urlPrefix + "es2020/userflow.js";
          } else {
            script.src = envVars.USERFLOWJS_LEGACY_URL || urlPrefix + "legacy/userflow.js";
          }
          script.onload = function() {
            resolve();
          };
          script.onerror = function() {
            document.head.removeChild(script);
            loadPromise = null;
            var e = new Error("Could not load Userflow.js");
            console.warn(e.message);
            reject(e);
          };
          document.head.appendChild(script);
        });
      }
      return loadPromise;
    }
  };
  q = w.USERFLOWJS_QUEUE = w.USERFLOWJS_QUEUE || [];
  stubVoid = function(method) {
    userflow[method] = function() {
      var args = Array.prototype.slice.call(arguments);
      userflow.load();
      q.push([method, null, args]);
    };
  };
  stubPromise = function(method) {
    userflow[method] = function() {
      var args = Array.prototype.slice.call(arguments);
      userflow.load();
      var deferred;
      var promise = new Promise(function(resolve, reject) {
        deferred = { resolve, reject };
      });
      q.push([method, deferred, args]);
      return promise;
    };
  };
  stubDefault = function(method, returnValue) {
    userflow[method] = function() {
      return returnValue;
    };
  };
  stubVoid("_setTargetEnv");
  stubVoid("closeResourceCenter");
  stubVoid("disableEvalJs");
  stubVoid("init");
  stubVoid("off");
  stubVoid("on");
  stubVoid("prepareAudio");
  stubVoid("registerCustomInput");
  stubVoid("remount");
  stubVoid("reset");
  stubVoid("setBaseZIndex");
  stubVoid("setCustomInputSelector");
  stubVoid("setCustomNavigate");
  stubVoid("setCustomScrollIntoView");
  stubVoid("setInferenceAttributeFilter");
  stubVoid("setInferenceAttributeNames");
  stubVoid("setInferenceClassNameFilter");
  stubVoid("setResourceCenterLauncherHidden");
  stubVoid("setScrollPadding");
  stubVoid("setServerEndpoint");
  stubVoid("setShadowDomEnabled");
  stubVoid("setPageTrackingDisabled");
  stubVoid("setUrlFilter");
  stubVoid("setLinkUrlDecorator");
  stubVoid("openResourceCenter");
  stubVoid("toggleResourceCenter");
  stubPromise("endAll");
  stubPromise("endAllFlows");
  stubPromise("endChecklist");
  stubPromise("group");
  stubPromise("identify");
  stubPromise("identifyAnonymous");
  stubPromise("start");
  stubPromise("startFlow");
  stubPromise("startWalk");
  stubPromise("track");
  stubPromise("updateGroup");
  stubPromise("updateUser");
  stubDefault("getResourceCenterState", null);
  stubDefault("isIdentified", false);
}
var urlPrefix;
var loadPromise;
var q;
var stubVoid;
var stubPromise;
var stubDefault;
var userflow$1 = userflow;
export {
  userflow$1 as default
};
//# sourceMappingURL=userflow__js.js.map
